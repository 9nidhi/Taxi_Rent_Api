const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const hotelbookingSchema = new Schema({
   
	city: {
		type: String,
        required: true,
	
	}
    
	
}, {timestamps: true});

const HotelBooking = mongoose.model('hotelbooking', hotelbookingSchema);

module.exports = HotelBooking;