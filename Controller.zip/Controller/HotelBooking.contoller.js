const _ = require('lodash');

const axios = require('axios');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');
const HotelBooking = require('../Models/HotelBooking.models'); // Assuming Distance model is imported
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;

const apiKey = '6690ab148a9f28b173dde639'; // Replace with your actual API key


exports.gethotel = async (req, res, next) => {
  const { city } = req.body;
  console.log('city =>',city);
  

  if (!city) {
    return res.status(400).json({ error: 'City name is required' });
  }

  try {
    // Fetch hotel data from MakCorps API using city name
    const url = `https://api.makcorps.com/city`;
    const params = {
      cityid: '60763',
      pagination: '0',
      cur: 'INR',
      rooms: '1',
      adults: '2',
      checkin: '2024-12-25',
      checkout: '2024-12-26',
      api_key: '6690c663e0ce67b165d857d4'
    };

    const response = await axios.get(url, { params });
    console.log('response =>',response);
    
    const hotels = response.data; // Adjust based on actual response structure from MakCorps

    // Return the list of hotels
    res.status(200).json({
      status: 'success',
      data: {
        hotels
      }
    });
  } catch (error) {
    // Handle errors
    console.error('Error fetching hotels:', error.message);
    res.status(500).json({ error: 'Error fetching hotels from MakCorps API' });
  }
};

// exports.gethotel = async (req, res, next) => {
//   const url = 'https://nominatim.openstreetmap.org/search';
//   const params = {
//     api_key: '6690c663e0ce67b165d857d4',
//     name: 'Gujrat'
//   };

//   try {
//     const response = await axios.get(url, { params });

//     // Send the response data as JSON
//     res.status(200).json({
//       status: 'success',
//       data: response.data // Pass the response data to the client
//     });
//   } catch (error) {
//     console.error('Error fetching mapping data:', error.message);
//     res.status(500).json({ error: 'Failed to fetch mapping data' }); // Handle error response
//   }
// };

