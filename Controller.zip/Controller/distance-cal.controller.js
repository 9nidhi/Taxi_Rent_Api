const _ = require('lodash');
const http = require('http');
const axios = require('axios');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');
const Distance = require('../Models/distance-cal.model'); // Assuming Distance model is imported
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;

const googleMapsApiKey = "AIzaSyB8WzQfww2uDUeO0mWCUHUskY0Y-FiRH2o";
console.log('googleMapsApiKey =>', googleMapsApiKey);

// exports.addDistance = catchAsync(async (req, res, next) => {
//     const { cityname1, cityname2 } = req.body;

//     if (!cityname1 || !cityname2) {
//       return res.status(400).json({ status: 'error', message: 'Please provide both city names.' });
//     }

//     try {
//       const url = `https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins=${encodeURIComponent(cityname1)}&destinations=${encodeURIComponent(cityname2)}&key=${googleMapsApiKey}`;

//       const response = await axios.get(url);

//       if (response.status !== 200) {
//         throw new Error('Failed to fetch distance data');
//       }

//       const distance = response.data.rows[0].elements[0].distance.value / 1000; // Distance in kilometers
//       const durationInSeconds = response.data.rows[0].elements[0].duration.value;
//       const hours = Math.floor(durationInSeconds / 3600);
//       const minutes = Math.floor((durationInSeconds % 3600) / 60);
//       const seconds = durationInSeconds % 60;

//       let durationString;
//       if (hours > 0) {
//         durationString = `${hours} hr ${minutes} min`;
//       } else {
//         durationString = `${minutes} min ${seconds} sec`;
//       }

//       res.json({
//         status: 'success',
//         message: 'Distance and duration calculated successfully.',
//         result: {
//           cityname1,
//           cityname2,
//           distance,
//           duration: durationString
//         }
//       });
//     } catch (error) {
//       console.error('Error calculating distance and duration:', error);
//       return res.status(500).json({ status: 'error', message: 'Failed to calculate distance and duration.' });
//     }
//   });


// exports.addDistance = catchAsync(async (req, res, next) => {
//   const { cityname1, cityname2 } = req.body;

//   if (!cityname1 || !cityname2) {
//     return res.status(400).json({ status: 'error', message: 'Please provide both city names.' });
//   }

//   try {
//     const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${encodeURIComponent(cityname1)}&destination=${encodeURIComponent(cityname2)}&mode=driving&key=${googleMapsApiKey}`;

//     const response = await axios.get(url);

//     if (response.status !== 200) {
//       throw new Error('Failed to fetch directions data');
//     }

//     const route = response.data.routes[0];
//     const distance = route.legs[0].distance.value / 1000; // Distance in kilometers
//     const durationInSeconds = route.legs[0].duration.value;
//     const hours = Math.floor(durationInSeconds / 3600);
//     const minutes = Math.floor((durationInSeconds % 3600) / 60);
//     const seconds = durationInSeconds % 60;

//     let durationString;
//     if (hours > 0) {
//       durationString = `${hours} hr ${minutes} min`;
//     } else {
//       durationString = `${minutes} min ${seconds} sec`;
//     }

//     res.json({
//       status: 'uccess',
//       message: 'Distance and duration calculated successfully.',
//       result: {
//         cityname1,
//         cityname2,
//         distance,
//         duration: durationString
//       }
//     });
//   } catch (error) {
//     console.error('Error calculating distance and duration:', error);
//     return res.status(500).json({ status: 'error', message: 'Failed to calculate distance and duration.' });
//   }
// });


const fetchDataFromGooglePlaces = async (type, region = 'India') => {
  const url = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${type}+in+${region}&key=${googleMapsApiKey}`;
  const response = await axios.get(url);
  
  if (response.data.status !== 'OK') {
      throw new Error('Error fetching data from Google Places API');
  }
  
  return response.data.results.map(place => place.formatted_address);
};

exports.getcity = catchAsync(async (req, res, next) => {
  try {
    const type = req.query.type || 'cities'; // Default to 'cities' if no type is provided
    console.log('type =>',type);
    
    const results = await fetchDataFromGooglePlaces(type);
    console.log('results =>',results);
    
    res.status(200).json(results);
  } catch (error) {
    next(error);
  }
});

exports.addDistance = catchAsync(async (req, res, next) => {
  const options = {
    method: 'GET',
    hostname: 'booking-com.p.rapidapi.com',
    port: null,
    path: '/v1/hotels/locations?name=Berlin&locale=en-gb',
    headers: {
      'x-rapidapi-key': '95ab973e11msh7afd3a40374047fp14c631jsnb90e482a446b',
      'x-rapidapi-host': 'booking-com.p.rapidapi.com'
    },
    timeout: 10000 // 10 seconds timeout
  };

  const apiReq = http.request(options, function (apiRes) {
    const chunks = [];

    apiRes.on('data', function (chunk) {
      chunks.push(chunk);
    });

    apiRes.on('end', function () {
      const body = Buffer.concat(chunks);
      const data = JSON.parse(body.toString());
      res.status(200).json(data); // Send the fetched data as JSON response
    });
  });

  apiReq.on('error', function (err) {
    console.error('Error with request:', err.message);
    next(err); // Forward error to Express error handler
  });

  apiReq.setTimeout(options.timeout, function () {
    apiReq.abort();
    console.error('Request timed out');
    const err = new Error('Request timed out');
    err.status = 408; // Request Timeout
    next(err); // Forward timeout error to Express error handler
  });

  apiReq.end();
});


const options = {
	method: 'GET',
	hostname: ' 127.0.0.1',
	port: 80,
	path: '/v1/hotels/locations?name=Surat&locale=en-gb',
	headers: {
		'x-rapidapi-key': '5a925ebd6dmshcdbbaaec02e7195p15fe9bjsneebe7e15a70b',
		'x-rapidapi-host': 'booking-com.p.rapidapi.com'
	}
};

const req = http.request(options, function (res) {
	const chunks = [];

	res.on('data', function (chunk) {
		chunks.push(chunk);
	});

	res.on('end', function () {
		const body = Buffer.concat(chunks);
    console.log('body =>',body);
    
		console.log(body.toString());
	});
});

req.end();