const router = require('express').Router();
const {addDistance,getcity} =  require('../Controller/distance-cal.controller')

router.get('/adddistance', addDistance);
router.get('/getcity', getcity);

module.exports = router;    

