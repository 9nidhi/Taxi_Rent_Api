const router = require('express').Router();
const {gethotel} =  require('../Controller/HotelBooking.contoller')

router.post('/gethotel', gethotel);
// router.post('/loginhotel', loginhotel);
module.exports = router;    

