const _ = require('lodash');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');
const OneWayRoute = require('../Models/OnewayRoute.model');
const mongoose = require('mongoose');
const CityName = require('../Models/CityName.model');



// API to add a route under a specific city by city ID from query parameters

exports.addRoute = catchAsync(async (req, res, next) => {
    const { routeName } = req.body; // Extracting routeName from the request body
    const { cityId } = req.query;   // Extracting cityId from query parameters

    // Logging for debugging purposes
    console.log('routeName =>', routeName);
    console.log('cityId =>', cityId);

    // Check if cityId and routeName are provided
    if (!cityId) {
        return next(new AppError('City ID is required', 400));
    }
    if (!routeName) {
        return next(new AppError('Route name is required', 400));
    }

    // Find the city by ID to get the cityName
    const existingCity = await CityName.findById(cityId);
    console.log('existingCity =>', existingCity);
    
    if (!existingCity) {
        return next(new AppError('City not found', 404));
    }

    // Check if the route already exists for the specified city
    const existingRoute = await OneWayRoute.findOne({ cityId });

    if (existingRoute) {
        // Check if the routeName already exists in the array
        if (existingRoute.routeNames.includes(routeName)) {
            return next(new AppError('Route already exists for this city', 400));
        }

        // If it exists, push the new routeName into the existing array
        existingRoute.routeNames.push(routeName);
        await existingRoute.save(); // Save the updated route
    } else {
        // If no existing route, create a new one
        const newRoute = await OneWayRoute.create({
            cityId,
            routeNames: [routeName], // Store as an array with the first route
            cityName: existingCity.cityname,
        });
    }

    // Send the response with the new route details
    const updatedRouteNames = existingRoute ? existingRoute.routeNames : [routeName]; // Get the updated array of route names
    res.status(201).json({
        status: 'success',
        data: {
            routeNames: updatedRouteNames,
            routeCityName: existingCity.cityname,
        },
    });
});



// delete city  
exports.deletecity = catchAsync(async (req, res, next) => {
    const { id } = req.params; // Extracting id from request parameters

    // Check if id is provided
    if (!id) {
        return next(new AppError('City ID is required', 400));
    }

    // Find and delete the city
    const deletedCity = await OneWayRoute.findByIdAndDelete(id);

    // If no city found, return an error
    if (!deletedCity) {
        return next(new AppError('City not found', 404));
    }

    // Send the response
    res.status(200).json({  // Changed to 200 OK to include a message
        status: 'success',
        message: 'City deleted successfully.',
        data: deletedCity, // Optional: you can include deletedCity if you want to return the deleted document
    });
});


// API to edit a route by route ID
exports.editroute = catchAsync(async (req, res, next) => {
    const { id } = req.params; // Extracting route ID from request parameters
    const { routeName, routeCityName } = req.body; // Extracting routeName and routeCityName from the request body

    // Check if ID, routeName, and routeCityName are provided
    if (!id) {
        return next(new AppError('Route ID is required', 400));
    }
    if (!routeName) {
        return next(new AppError('Route name is required', 400));
    }
    if (!routeCityName) {
        return next(new AppError('City name is required', 400));
    }

    // Find the route by ID and update it
    const updatedRoute = await OneWayRoute.findByIdAndUpdate(
        id,
        { routeName, routeCityName }, // Update with the new routeName and routeCityName
        { new: true, runValidators: true } // Return the updated document and run validators
    );

    // If no route found, return an error
    if (!updatedRoute) {
        return next(new AppError('Route not found', 404));
    }

    // Send the response
    res.status(200).json({
        status: 'success',
        data: {
            routeName: updatedRoute.routeName,
            routeCityName: updatedRoute.routeCityName,
        },
    });
});


exports.getroutebycity = catchAsync(async (req, res, next) => {
    const { cityName } = req.query; // Extracting cityName from query parameters

    // Logging for debugging
    console.log('Received cityName:', cityName);

    // Check if cityName is provided
    if (!cityName) {
        return next(new AppError('City name is required', 400));
    }

    // Find the city in the CityName model to confirm it exists
    const existingCity = await CityName.findOne({ cityname: cityName });
    console.log('Found city:', existingCity);

    // Check if the city exists
    if (!existingCity) {
        return next(new AppError('City not found', 404));
    }

    // Find routes associated with the specified city name from OneWayRoute model
    const routes = await OneWayRoute.find({ routeCityName: cityName });

    // Check if routes are found for the given city name
    if (!routes.length) {
        return next(new AppError('No routes found for this city', 404));
    }

    // Send the response with the retrieved routes
    res.status(200).json({
        status: 'success',
        data: {
            routes,
        },
    });
});


