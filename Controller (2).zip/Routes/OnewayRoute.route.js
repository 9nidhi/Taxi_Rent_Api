const router = require('express').Router();
const {addRoute,deletecity,editroute,getroutebycity} =  require('../Controller/OnewayRoute.controller')


router.post('/addroute', addRoute);
router.delete('/deletecity/:id', deletecity);
router.patch('/editroute/:id', editroute);
router.get('/getroutebycity', getroutebycity);

module.exports = router;    

