const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const OneWayRouteSchema = new Schema({
    
    
    routeNames: {
        type: [String], // Change to an array of strings
        required: true,
    },
    routeCityName:{
        type: String,
    }

}, { timestamps: true });


const OneWayRoute = mongoose.model('oneWayRoute', OneWayRouteSchema);

module.exports = OneWayRoute;
